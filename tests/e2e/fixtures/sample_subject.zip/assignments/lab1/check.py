#!/usr/bin/env python3
"""E2E test check script — passes if solution.txt exists in /submission."""

import json
import os
from pathlib import Path

submission_dir = Path("/submission")
output_dir = Path("/output")
output_dir.mkdir(parents=True, exist_ok=True)

solution_exists = (submission_dir / "solution.txt").exists()

result = {
    "tests": [
        {
            "name": "solution.txt exists",
            "description": "The submission must contain a file named solution.txt",
            "passed": solution_exists,
            "points_earned": 1 if solution_exists else 0,
            "max_points": 1,
            "message": "OK" if solution_exists else "solution.txt not found in submission root",
        }
    ]
}

(output_dir / "result.json").write_text(json.dumps(result))
